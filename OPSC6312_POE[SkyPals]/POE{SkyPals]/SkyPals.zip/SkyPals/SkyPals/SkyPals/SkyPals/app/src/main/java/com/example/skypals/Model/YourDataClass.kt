package com.example.skypals.Model

import android.graphics.Bitmap

class YourDataClass() {
    var image: String = ""
    var title: String = ""
    var Obsdate: String  = ""
    var description: String = ""
    var location: String = ""

    constructor(image: String, title: String, obsDate: String, description: String, location: String): this(){
        this.image = image
        this.title = title
        this.Obsdate = obsDate
        this.description = description
        this.location = location
    }
}