package com.example.skypals

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat.getSystemService
import coil.load
import com.example.skypals.Adapter.UserObservationsAdapter
import com.example.skypals.Model.UserObservations
import com.example.skypals.Model.YourDataClass
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import java.io.ByteArrayOutputStream
import java.util.*

class CollectionFragment : Fragment() {

    private val userObservations = mutableListOf<UserObservations>()

    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var lastLocation: android.location.Location
    companion object {
        private const val GALLERY_REQUEST_CODE = 1
        private const val CAMERA_REQUEST_CODE = 2
        private const val LOCATION_PERMISSION_REQUEST_CODE = 3
    }
    private lateinit var database: DatabaseReference
    private lateinit var storage: FirebaseStorage
    private lateinit var currentUser: FirebaseUser

    private lateinit var editTextTitle: EditText
    private lateinit var editTextDate: EditText
    private lateinit var editTextILocation: TextView
    private lateinit var editTextObsDescription: EditText
    private lateinit var imageViewObservationsImage: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_collection, container, false)

        //Using fusedLocationProviderClient to get user's current location
        fusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(requireContext())

        val auth = FirebaseAuth.getInstance()
        currentUser = auth.currentUser!!

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference
        // Initialize Firebase Storage
        storage = FirebaseStorage.getInstance()

        val listViewObservations = view.findViewById<ListView>(R.id.listViewObservation)
        val userObservationsAdapter = UserObservationsAdapter(requireContext(), userObservations)


        imageViewObservationsImage = view.findViewById(R.id.imageView)
        imageViewObservationsImage.setOnClickListener {
            val pictureDialog = AlertDialog.Builder(requireContext())
            pictureDialog.setTitle("Select Action")
            val pictureDialogItem = arrayOf("Select photo from gallery", "Take a photo")
            pictureDialog.setItems(pictureDialogItem) { dialog, which ->

                when (which) {
                    0 -> galleryCheckPermission()
                    1 -> cameraCheckPermission()
                }
            }
            pictureDialog.show()
        }

        listViewObservations.adapter = userObservationsAdapter

        val btn_addObservation = view.findViewById<Button>(R.id.addObservations)
        btn_addObservation.setOnClickListener {

            val TextViewLocation = view.findViewById<TextView>(R.id.TextViewLocation1)
            if (ActivityCompat.checkSelfPermission(
                    requireContext(),
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationProviderClient.lastLocation
                    .addOnSuccessListener { location: android.location.Location? ->
                        location ?: run {
                            Toast.makeText(
                                requireContext(),
                                "Unable to retrieve location",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@addOnSuccessListener
                        }
                            lastLocation = location
                            val itemLocation = "${lastLocation.latitude}, ${lastLocation.longitude}"
                            // Set the obtained location to the TextView
                            TextViewLocation.text = itemLocation

                            val editTextTitle = view.findViewById<EditText>(R.id.editTextItemTitle)
                            val editTextDate = view.findViewById<EditText>(R.id.editTextDate)
                            val editTextDescription =
                                view.findViewById<EditText>(R.id.editTextItemDescription)
                            val imageObservations = view.findViewById<ImageView>(R.id.imageView)
                            val itemImage = (imageObservations.drawable as BitmapDrawable).bitmap

                            val itemTitle = editTextTitle.text.toString()
                            val itemDate = editTextDate.text.toString()
                            val itemDescription = editTextDescription.text.toString()

                            // Validation
                            if (itemTitle.isEmpty()) {
                                Toast.makeText(
                                    requireContext(),
                                    "Please enter a title",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@addOnSuccessListener
                            }
                            if (itemDate.isEmpty()) {
                                Toast.makeText(
                                    requireContext(),
                                    "Please enter a date",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@addOnSuccessListener
                            }
                            if (itemDescription.isEmpty()) {
                                Toast.makeText(
                                    requireContext(),
                                    "Please enter a description",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@addOnSuccessListener
                            }
                            if (itemImage == null) {
                                Toast.makeText(
                                    requireContext(),
                                    "Please select an image",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@addOnSuccessListener
                            }

                            val observations = UserObservations(
                                image = itemImage,
                                title = itemTitle,
                                Obsdate = itemDate,
                                description = itemDescription,
                                location = itemLocation
                            )

                            userObservations.add(observations)

                            userObservationsAdapter.notifyDataSetChanged()

                            Toast.makeText(
                                requireContext(),
                                "Observation added successfully",
                                Toast.LENGTH_SHORT
                            ).show()


                        }




            }else {
                ActivityCompat.requestPermissions(
                    requireActivity(),
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                    LOCATION_PERMISSION_REQUEST_CODE
                )
            }
            saveItemToFirebase()
        }

        val databaseReference = database.child("All Observations")

        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                userObservations.clear()
                for (itemSnapshot in snapshot.children) {
                    val yourDataClass = itemSnapshot.getValue(YourDataClass::class.java)
                    yourDataClass?.let {
                        val obs = UserObservations(
                            image = yourDataClass.image,
                            title = yourDataClass.title,
                            Obsdate = yourDataClass.Obsdate,
                            description = yourDataClass.description,
                            location = yourDataClass.location
                        )
                        userObservations.add(obs)
                    }
                }
                userObservationsAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle the onCancelled event
            }
        })

        return view
    }


    private fun saveItemToFirebase() {
        editTextTitle = requireView().findViewById(R.id.editTextItemTitle)
        editTextDate = requireView().findViewById(R.id.editTextDate)
        editTextILocation = requireView().findViewById(R.id.TextViewLocation1)
        editTextObsDescription = requireView().findViewById(R.id.editTextItemDescription)

        val title = editTextTitle.text.toString().trim()
        val date = editTextDate.text.toString().trim()
        val location = editTextILocation.text.toString().trim()
        val description = editTextObsDescription.text.toString().trim()
        val image = imageViewObservationsImage.drawable
        val builder = AlertDialog.Builder(requireContext())
        builder.setCancelable(false)
        val dialog: AlertDialog = builder.create()


        if (title.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter a title", Toast.LENGTH_SHORT).show()
            return
        }
        if (date.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter a date", Toast.LENGTH_SHORT).show()
            return
        }

        if (description.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter a description", Toast.LENGTH_SHORT).show()
            return
        }

        if (image == null) {
            Toast.makeText(requireContext(), "Please select an image", Toast.LENGTH_SHORT).show()
            return
        }

        val imageBitmap = (image as BitmapDrawable).bitmap
        val baos = ByteArrayOutputStream()
        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()

        val filename = UUID.randomUUID().toString()
        val imageRef = storage.reference.child("images/$filename.jpg")
        val user = Firebase.auth.currentUser
        val uploadTask = imageRef.putBytes(data)
        uploadTask.continueWithTask { task ->
            if (!task.isSuccessful) {
                task.exception?.let {
                    throw it
                }
            }
            imageRef.downloadUrl
        }.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val downloadUri = task.result
                val item = YourDataClass(
                    downloadUri.toString(),
                    title,
                    date,
                    description,
                    location)

                val itemId = database.child("Observations").push().key
                if (itemId != null) {


                    database.child("All Observations").child(itemId).setValue(item)
                        .addOnCompleteListener { saveTask ->
                            if (saveTask.isSuccessful) {
                                Toast.makeText(
                                    requireContext(),
                                    "Observation saved successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                                editTextTitle.setText("")
                                editTextDate.setText("")
                                editTextObsDescription.setText("")
                            } else {
                                Toast.makeText(
                                    requireContext(),
                                    "Failed to save observation",
                                    Toast.LENGTH_SHORT
                                ).show()
                                dialog.dismiss()
                            }
                        }
                }
            } else {
                Toast.makeText(
                    requireContext(),
                    "Failed to upload image",
                    Toast.LENGTH_SHORT
                ).show()
                dialog.dismiss()
            }
        }
    }

    private fun galleryCheckPermission() {
        Dexter.withContext(requireContext()).withPermission(
            Manifest.permission.READ_EXTERNAL_STORAGE
        ).withListener(object : PermissionListener {
            override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                gallery()
            }

            override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                Toast.makeText(
                    requireContext(), "You have denied the storage permission" +
                            "in order to select an image", Toast.LENGTH_SHORT
                ).show()


            }

            override fun onPermissionRationaleShouldBeShown(
                p0: PermissionRequest?,
                p1: PermissionToken?
            ) {

            }


        }).onSameThread().check()
    }

    private fun gallery(){
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    private fun cameraCheckPermission() {
        Dexter.withContext(requireContext())
            .withPermission(Manifest.permission.CAMERA)
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(response: PermissionGrantedResponse?) {
                    // Permission is granted, proceed with camera operation
                    camera()
                }

                override fun onPermissionDenied(response: PermissionDeniedResponse?) {
                    Toast.makeText(
                        requireContext(),
                        "Camera permission denied",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onPermissionRationaleShouldBeShown(
                    permission: PermissionRequest?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            })
            .check()
    }

    private fun camera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(resultCode == Activity.RESULT_OK){
            when(requestCode){
                ///
                CAMERA_REQUEST_CODE->{

                    val bitmap = data?.extras?.get("data") as Bitmap

                    imageViewObservationsImage.load(bitmap)
                }
                GALLERY_REQUEST_CODE->{
                    imageViewObservationsImage.load(data?.data){}
                }

            }
        }
    }

}

