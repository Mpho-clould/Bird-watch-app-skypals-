package com.example.skypals.Model

import android.graphics.Bitmap

class Observations(
    val obsIamge: Bitmap,
    val observer: String,
    val description: String,
    val lat: String,
    val lng: String,
    val date: String
){
    var id: Long = 0
}