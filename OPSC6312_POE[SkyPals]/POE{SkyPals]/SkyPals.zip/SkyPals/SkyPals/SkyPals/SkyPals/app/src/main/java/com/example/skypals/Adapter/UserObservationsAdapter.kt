package com.example.skypals.Adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.skypals.Model.UserObservations
import com.example.skypals.R
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import okhttp3.Dispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.ByteArrayInputStream

class UserObservationsAdapter(private val context: Context, private val userObservation: List<UserObservations>):
                            BaseAdapter() {

    private val layoutInflater = LayoutInflater.from(context)
    private val storageRef: StorageReference = FirebaseStorage.getInstance().reference

    override fun getCount(): Int {
        return userObservation.size
    }

    override fun getItem(position: Int): Any {
        return userObservation[position]
    }

    override fun getItemId(position: Int): Long {
        return userObservation[position].id
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view =
            convertView ?: layoutInflater.inflate(R.layout.observation_list_cardview, parent, false)
        val userObs = userObservation[position]

        val textViewName = view.findViewById<TextView>(R.id.textViewObservationName)
        val textViewDate = view.findViewById<TextView>(R.id.textViewDate)
        val textViewDescription = view.findViewById<TextView>(R.id.textViewDescription)
        val imageViewObservation = view.findViewById<ImageView>(R.id.imageViewObs)
        val textViewLocation = view.findViewById<TextView>(R.id.textViewLocation)

        textViewName.text = userObs.title
        textViewDate.text = userObs.Obsdate
        textViewDescription.text = userObs.description
        textViewLocation.text = userObs.location

        //load the image from firebase storage
        loadObservationImage(userObs.image, imageViewObservation)
        return view
    }

    private fun loadObservationImage(image: Bitmap, imageViewObservation: ImageView) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val storageReference = storageRef.child("images/$image.jpg")
                val maxImageSizeBytes: Long = 1024 * 1024 // 1MB
                val imageStream = storageReference.getBytes(maxImageSizeBytes).await()
                val bitmap = BitmapFactory.decodeStream(ByteArrayInputStream(imageStream))
                CoroutineScope(Dispatchers.Main).launch {
                    imageViewObservation.setImageBitmap(bitmap)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}