package com.example.skypals.Model

import android.graphics.Bitmap

class UserObservations (
    val image: Bitmap,
    val title: String,
    val Obsdate: String,
    val description: String,
    val location: String,
        ){

    var id: Long = 0

    constructor(image: String, title: String, Obsdate: String, description: String, location: String) :
            this(Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8), title, Obsdate, description, location)
}
